Name: Nevin Wong Syum Ganesan
Student ID: 8831598
Section :Section C

Name: Nicholas Broadbent
Student ID: 8709720
Section: Section C

Description: ITI1121 Assignment 5, this archive contains 15 files and one folder for Javadoc.

The 15 files are: Distance.java, FrequencyTable.java, Iterator.java, LinearFrequencyTable.java, TreeFrequencyTable.java, LinkedList.java, LinkedStack.java, Stack.java, Test.java, TestDistance.java, TestFrequencyTable.java, TestLinkedList.java, TestLinkedList.java, Utils.java and StudentInfo.java.