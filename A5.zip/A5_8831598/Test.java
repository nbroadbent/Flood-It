public class Test {

    public static void main(String[] args) {
    StudentInfo.display();
	TestFrequencyTable.main(args);
	TestDistance.main(args);
	TestLinkedList.main(args);
	TestLinkedStack.main(args);
	
    }

}