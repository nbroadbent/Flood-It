public class EmptyStackException extends IllegalStateException{
	//creates Empty Stack Exception
    public EmptyStackException(String message) {
        super(message);
    }
 
}