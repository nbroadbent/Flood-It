Name: Nevin Wong Syum Ganesan
Student ID: 8831598
Section :Section C

Name: Nicholas Broadbent
Student ID: 8709720
Section: Section C

Description: ITI1121 Assignment 3, this archive contains 9 files,
DotButton.java, DotInfo.java, FloodIt.java, GameController.java, GameModel.java, GameView.java, Stack.java, GameStack.java and StudentInfo.java.